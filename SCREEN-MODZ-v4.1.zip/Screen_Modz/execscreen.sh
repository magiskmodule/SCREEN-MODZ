#!/system/bin/sh
ver=4.1
dev=@HenVx
echo ""
echo "
█▀ █▀▀ █▀█ █▀▀ █▀▀ █▄░█ █▀▄▀█ █▀█ █▀▄ ▀█
▄█ █▄▄ █▀▄ ██▄ ██▄ █░▀█ █░▀░█ █▄█ █▄▀ █▄"
sleep 2
echo "[ 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻 𝗔𝗯𝗼𝘂𝘁 ] "
echo "Developer : ${dev} "
echo "Version : ${ver} "
echo ""
sleep 2
echo "[ 𝗦𝘂𝗽𝗽𝗼𝗿𝘁 𝗠𝗲 ]"
sleep 0.5
echo " Resource: https://t.me/HenVx1  "
sleep 0.5
echo " Discussion: https://t.me/HenVx10 "
sleep 2
echo ""
sleep 5
echo "[■□□□□□□□□□]  "
sleep 0.5
echo "[■■□□□□□□□□]  "
sleep 1
echo "[■■■□□□□□□□]  "
sleep 2
echo "[■■■■□□□□□□]  "
sleep 2
echo "[■■■■■□□□□□]  "
sleep 1
echo "[■■■■■■□□□□]  "
sleep 0.5
echo "[■■■■■■■□□□]  "
sleep 2
echo "[■■■■■■■■□□]  "
sleep 0.5
echo "[■■■■■■■■■□] "
sleep 2
echo "[■■■■■■■■■■] "
sleep 0.5
echo "Done"
echo ""
sleep 2
(
settprops=(
"debug.touchscreen.latency.scale 2"
"debug.sf.late.sf.duration 2000000"
"debug.sf.use_phase_offsets_as_durations 1"
"debug.sf.late.app.duration 6000000"
"debug.sf.frame_rate_multiple_threshold 165"
"debug.sf.earlyGl.sf.duration 16600000"
"debug.sf.earlyGl.app.duration 16600000"
"debug.sf.early.app.duration 16600000"
"debug.sf.early.sf.duration 16600000"
"log.tag.FragmentManager 0"
"log.tag.Games INFO"
"debug.demo.rotationlock false"
"debug.demo.singledisplay true"
"debug.firebase.analytics.app none"
"debug.enable-vr-mode 1"
"debug.force-opengl 1"
"debug.hwc.force_gpu_vsync 1"
"debug.performance.profile 1"
"debug.refresh_rate.min_fps 90"
)
secures=(
"multi_press_timeout 100"
"long_press_timeout 130"
"touch_exploration_enabled 1"
"wake_gesture_enabled 0"
"screensaver_enabled 0"
)
globals=(
"window_animation_scale 0.19"
"transition_animation_scale 0.19"
"animator_duration_scale 0.19"
"animator_slow_preview 0"
"cached_apps_freezer 1"
"enable_gpu_debug_layers 0"
)
for settprop in "${settprops[@]}"; do
setprop $settprop
done
for secure in "${secures[@]}"; do
settings put --user current secure $secure
done
for global in "${globals[@]}"; do
settings put --user current global $global
done
)> /dev/null 2>&1
cmd notification post -S bigtext -t 'SCREEN MODZ' 'Tag' 'ACTIVATED!!' > /dev/null 2>&1