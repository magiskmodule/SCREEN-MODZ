#ladb/android/system/modules/hen/id/remove

echo ""
echo "
█▀ █▀▀ █▀█ █▀▀ █▀▀ █▄░█ █▀▄▀█ █▀█ █▀▄ ▀█
▄█ █▄▄ █▀▄ ██▄ ██▄ █░▀█ █░▀░█ █▄█ █▄▀ █▄"
echo ""
sleep 0.5
echo ""
echo " Remove Screen MODZ"
sleep 5
echo ""
echo " Succes "
echo ""
sleep 2
(
settings put secure multi_press_timeout 400
settings put secure long_press_timeout 400
settings delete secure touch_exploration_enabled
settings put global window_animation_scale 2
settings put global transition_animation_scale 2
settings put global animator_duration_scale 2
)> /dev/null 2>&1